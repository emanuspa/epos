﻿(function () {
    "use strict";

    var list = new WinJS.Binding.List();
    var groupedItems = list.createGrouped(
        function groupKeySelector(item) { return item.group.key; },
        function groupDataSelector(item) { return item.group; }
    );

    // TODO: Replace the data with your real data.
    // You can add data from asynchronous sources whenever it becomes available.
    generateSampleData().forEach(function (item) {
        list.push(item);
    });

    WinJS.Namespace.define("Data", {
        items: groupedItems,
        groups: groupedItems.groups,
        getItemReference: getItemReference,
        getItemsFromGroup: getItemsFromGroup,
        resolveGroupReference: resolveGroupReference,
        resolveItemReference: resolveItemReference
    });

    // Get a reference for an item, using the group key and item title as a
    // unique reference to the item that can be easily serialized.
    function getItemReference(item) {
        return [item.group.key, item.title];
    }

    // This function returns a WinJS.Binding.List containing only the items
    // that belong to the provided group.
    function getItemsFromGroup(group) {
        return list.createFiltered(function (item) { return item.group.key === group.key; });
    }

    // Get the unique group corresponding to the provided group key.
    function resolveGroupReference(key) {
        for (var i = 0; i < groupedItems.groups.length; i++) {
            if (groupedItems.groups.getAt(i).key === key) {
                return groupedItems.groups.getAt(i);
            }
        }
    }

    // Get a unique item from the provided string array, which should contain a
    // group key and an item title.
    function resolveItemReference(reference) {
        for (var i = 0; i < groupedItems.length; i++) {
            var item = groupedItems.getAt(i);
            if (item.group.key === reference[0] && item.title === reference[1]) {
                return item;
            }
        }
    }

    // Returns an array of sample data that can be added to the application's
    // data list. 
    function generateSampleData() {

        // These three strings encode placeholder images. You will want to set the
        // backgroundImage property in your real data to be URLs to images.
        var darkGray = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXY3B0cPoPAANMAcOba1BlAAAAAElFTkSuQmCC";
        var lightGray = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXY7h4+cp/AAhpA3h+ANDKAAAAAElFTkSuQmCC";
        var mediumGray = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXY5g8dcZ/AAY/AsAlWFQ+AAAAAElFTkSuQmCC";

        // Each of these sample groups must have a unique key to be displayed
        // separately.
        var sampleGroups = [
            { key: "group1", title: "Samples", subtitle: "ePOS-Print samples", backgroundImage: darkGray, description: "ePOS-Print samples" },
            { key: "group2", title: "Settings", subtitle: "ePOS-Print settings", backgroundImage: lightGray, description: "ePOS-Print settings" }
        ];

        // Each of these sample items should have a reference to a particular
        // group.
        var sampleItems = [
            {
                group: sampleGroups[0],
                title: "Queue Ticket",
                subtitle: "ePOS-Print API",
                description: "Prints queue ticket numbers.",
                content: "<p></p>",
                backgroundImage: lightGray,
                button: "Print",
                ready: function () {
                    document.querySelector(".article-button").onclick = printTicket;
                }
            },
            {
                group: sampleGroups[0],
                title: "Coupon",
                subtitle: "ePOS-Print Canvas API",
                description: "Prints coupons.",
                content: "<p></p>",
                backgroundImage: darkGray,
                button: "Print",
                ready: function () {
                    document.querySelector(".article-button").onclick = printCoupon;
                }
            },
            {
                group: sampleGroups[0],
                title: "Label",
                subtitle: "ePOS-Print API",
                description: "Prints labels.",
                content: "<p></p>",
                backgroundImage: mediumGray,
                button: "Print",
                ready: function () {
                    document.querySelector(".article-button").onclick = printLabel;
                }
            },
            {
                group: sampleGroups[1],
                title: "Printer",
                subtitle: "ePOS-Print API, ePOS-Print Canvas API",
                description: "Sets the target printer and printing options.",
                content: "<p>IP address of ePOS-Print supported printer<br /><input id='ipaddr' type='text'></p><p>Device ID of the target printer<br /><input id='devid' type='text'></p><p>Print timeout (milliseconds)<br /><input id='timeout' type='text'></p><p><input id='grayscale' type='checkbox'>Print in grayscale (Coupon)<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Only for supported models)</p><p><input id='layout' type='checkbox'>Set the paper layout (Label)<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Only for TM-P60II)</p>",
                backgroundImage: darkGray,
                button: "Save",
                ready: function () {
                    loadSettings();
                    document.querySelector(".article-button").onclick = saveSettings;
                }
            }
        ];

        return sampleItems;
    }
})();
